#include<iostream>
#include"LZAlgorithm.h"
using namespace std;

int main(int argc, char* argv[])
{
    compress(argv[1], argv[2]);
    //decompress(argv[1], argv[2]);

    return 0;
}